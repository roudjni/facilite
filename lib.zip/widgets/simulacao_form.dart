// lib/widgets/emprestimo/simulacao_form.dart
import 'package:emprestafacil/app/app_state.dart';
import 'package:emprestafacil/data/models/simulacao.dart';
import 'package:emprestafacil/theme/app_theme.dart';
import 'package:emprestafacil/widgets/shared/shared_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

typedef SimulacaoCallback = Function(
    double totalComJuros, List<Map<String, dynamic>> parcelasDetalhadas);

class SimulacaoForm extends StatefulWidget {
  final Simulacao? simulacao;
  final SimulacaoCallback onSimulacaoCalculada;
  const SimulacaoForm({Key? key, this.simulacao, required this.onSimulacaoCalculada})
      : super(key: key);

  @override
  State<SimulacaoForm> createState() => SimulacaoFormState();
}

class SimulacaoFormState extends State<SimulacaoForm> {
  final _formKey = GlobalKey<FormState>();
  final _nomeController = TextEditingController();
  final _valorController = TextEditingController();
  final _parcelasController = TextEditingController();
  final _jurosController = TextEditingController();
  String _tipoParcela = 'Mensais';
  DateTime? _dataVencimento;

  @override
  void initState() {
    super.initState();
    if (widget.simulacao != null) {
      _nomeController.text = widget.simulacao!.nome;
      _valorController.text =
          widget.simulacao!.valor.toStringAsFixed(2);
      _parcelasController.text = widget.simulacao!.parcelas.toString();
      _jurosController.text = widget.simulacao!.juros.toString();
      _tipoParcela = widget.simulacao!.tipoParcela;
      _dataVencimento = widget.simulacao!.dataVencimento;
    }
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _valorController.dispose();
    _parcelasController.dispose();
    _jurosController.dispose();
    super.dispose();
  }

  void _calcularSimulacao() {
    if (!_formKey.currentState!.validate()) return;

    final appState = Provider.of<AppState>(context, listen: false);

    double valor =
    double.parse(_valorController.text.replaceAll('.', '').replaceAll(',', '.'));
    int parcelasNum = int.parse(_parcelasController.text);
    double juros = double.parse(_jurosController.text) / 100;

    appState.setValor(valor);
    appState.setParcelas(parcelasNum);
    appState.setJuros(juros * 100);
    appState.setTipoParcela(_tipoParcela);
    appState.setDataVencimento(_dataVencimento ?? DateTime.now());
    appState.calcularSimulacao('simulacao'); // Poderia passar a origem se necessário

    // Notifica a tela pai sobre os novos valores
    widget.onSimulacaoCalculada(appState.totalComJuros, appState.parcelasDetalhadas);
  }

  void _formatarValor(TextEditingController controller, String value) {
    final appState = Provider.of<AppState>(context, listen: false);
    value = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (value.isEmpty) {
      controller.text = '';
      return;
    }
    final parsed = double.parse(value) / 100;
    controller.text = appState.numberFormat.format(parsed).replaceAll('R\$', '');
    controller.selection = TextSelection.fromPosition(
      TextPosition(offset: controller.text.length),
    );
  }

  // Método para obter os dados da simulação (será usado pela tela pai)
  Simulacao getSimulacaoData() {
    return Simulacao(
      nome: _nomeController.text,
      valor: double.parse(
          _valorController.text.replaceAll('.', '').replaceAll(',', '.')),
      parcelas: int.parse(_parcelasController.text),
      juros: double.parse(_jurosController.text),
      data: DateTime.now(), // Você pode ajustar isso se necessário
      tipoParcela: _tipoParcela,
      parcelasDetalhes:
      Provider.of<AppState>(context, listen: false).parcelasDetalhadas,
      dataVencimento: _dataVencimento ?? DateTime.now(),
    );
  }

  Map<String, dynamic> getCamposCalculados() {
    final appState = Provider.of<AppState>(context, listen: false);
    return {
      'totalComJuros': appState.totalComJuros,
      'parcelasDetalhadas': appState.parcelasDetalhadas,
    };
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return Form(
      key: _formKey,
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: AppTextField(
                  controller: _nomeController,
                  label: 'Nome do Cliente',
                  icon: Icons.person_outline,
                  validator: (value) =>
                  value?.isEmpty ?? true ? 'Digite o nome do cliente' : null,
                  onChanged: (value) => appState.setNome(value),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: AppTextField(
                  controller: _valorController,
                  label: 'Valor do Empréstimo',
                  icon: Icons.attach_money,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (value) =>
                  value?.isEmpty ?? true ? 'Digite o valor' : null,
                  onChanged: (value) => _formatarValor(_valorController, value),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: AppTextField(
                  controller: _parcelasController,
                  label: 'Número de Parcelas',
                  icon: Icons.calendar_today,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (value) => value?.isEmpty ?? true
                      ? 'Digite o número de parcelas'
                      : null,
                  onChanged: (value) {
                    if (value.isNotEmpty) {
                      appState.setParcelas(int.parse(value));
                    }
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: AppDropdown(
                  value: _tipoParcela,
                  label: 'Periodicidade',
                  icon: Icons.access_time,
                  items: ['Diárias', 'Semanais', 'Quinzenais', 'Mensais']
                      .map((tipo) => DropdownMenuItem(
                      value: tipo,
                      child: Text(tipo,
                          style: const TextStyle(color: Colors.white))))
                      .toList(),
                  onChanged: (value) => setState(() {
                    _tipoParcela = value!;
                    appState.setTipoParcela(value);
                  }),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: AppTextField(
                  controller: _jurosController,
                  label: 'Taxa de Juros (%)',
                  icon: Icons.percent,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (value) =>
                  value?.isEmpty ?? true ? 'Digite a taxa de juros' : null,
                  onChanged: (value) {
                    if (value.isNotEmpty) {
                      appState.setJuros(double.parse(value));
                    }
                  },
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: InkWell(
                  onTap: () async {
                    final dataSelecionada = await showDatePicker(
                      context: context,
                      initialDate: _dataVencimento ?? DateTime.now(),
                      firstDate: DateTime(DateTime.now().year - 1),
                      lastDate: DateTime(DateTime.now().year + 1),
                    );
                    if (dataSelecionada != null) {
                      setState(
                              () => _dataVencimento = dataSelecionada);
                      appState.setDataVencimento(dataSelecionada);
                    }
                  },
                  child: IgnorePointer(
                    child: AppTextField(
                      label: 'Data de Vencimento',
                      icon: Icons.calendar_month_outlined,
                      keyboardType: TextInputType.none,
                      validator: (value) =>
                      value?.isEmpty ?? true ? 'Selecione a data' : null,
                      controller: TextEditingController(
                        text: _dataVencimento != null
                            ? appState.dateFormat.format(_dataVencimento!)
                            : null,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _calcularSimulacao,
            child: const Text('Calcular Simulação'),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildSimulacaoCard(AppState appState) {
    return AppCard(
      child: Column(
        children: [
          Container(
            padding: AppTheme.cardPadding,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withOpacity(0.1),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Total a Pagar',
                      style: TextStyle(fontSize: 14, color: Colors.grey[400]),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      appState.numberFormat.format(appState.totalComJuros),
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${appState.parcelasDetalhadas.length}x de ${appState.numberFormat.format(appState.parcelasDetalhadas[0]['valor'])}',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      _tipoParcela.toLowerCase(),
                      style: TextStyle(fontSize: 14, color: Colors.grey[400]),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: AppTheme.cardPadding,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Parcela',
                          style: TextStyle(color: Colors.grey[400]),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Valor',
                          style: TextStyle(color: Colors.grey[400]),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Vencimento',
                          style: TextStyle(color: Colors.grey[400]),
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1, color: Colors.white24),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: appState.parcelasDetalhadas.length,
                  itemBuilder: (context, index) {
                    final parcela = appState.parcelasDetalhadas[index];
                    return Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(color: Colors.grey.withOpacity(0.1)),
                        ),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              '${parcela['numero']}ª',
                              style: TextStyle(
                                color: Theme.of(context).primaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Text(
                              appState.numberFormat.format(parcela['valor']),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Text(
                              parcela['dataVencimento'],
                              style: TextStyle(color: Colors.grey[400]),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
