import 'dart:convert';

import 'package:emprestafacil/screens/dashboard/dashboard_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:emprestafacil/app/app_state.dart';
import 'package:emprestafacil/widgets/side_menu.dart';
import 'package:emprestafacil/widgets/custom_appbar.dart';

class EmprestimosScreen extends StatefulWidget {
  @override
  _EmprestimosScreenState createState() => _EmprestimosScreenState();
}

class _EmprestimosScreenState extends State<EmprestimosScreen> {
  bool _isLoading = false;
  bool _isFirstLoad = true;
  bool _rebuildGrid = false;

  Future<void> _loadEmprestimos() async {
    setState(() {
      _isLoading = true;
    });
    await Provider.of<AppState>(context, listen: false).loadAllEmprestimos();
    setState(() {
      _isLoading = false;
      _rebuildGrid = true;
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isFirstLoad) {
      _loadEmprestimos();
      _isFirstLoad = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);

    return Scaffold(
      appBar: const CustomAppBar(title: 'Todos os Empréstimos'),
      drawer: const SideMenu(),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildQuickActionButton(
                  context: context,
                  icon: Icons.add_circle_outline,
                  label: 'Criar Empréstimo',
                  color: Colors.blue,
                  onTap: () => Navigator.pushNamed(context, '/criar-emprestimo'),
                ),
                _buildQuickActionButton(
                  context: context,
                  icon: Icons.calculate,
                  label: 'Simular Empréstimo',
                  color: Colors.orange,
                  onTap: () => Navigator.pushNamed(context, '/simulacao'),
                ),
                _buildQuickActionButton(
                  context: context,
                  icon: Icons.update,
                  label: 'Atualizar Status',
                  color: Colors.green,
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Atualizando status...')),
                    );
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: Column(
              children: [
                Expanded(
                  child: _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : appState.paginatedEmprestimos.isEmpty
                      ? const Center(child: Text('Nenhum empréstimo encontrado.'))
                      : Padding(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount:
                        MediaQuery.of(context).size.width > 1200 ? 4 : 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 8, // Reduzido de 12 para 8
                        childAspectRatio: 2,
                      ),
                      itemCount: appState.paginatedEmprestimos.length,
                      // Inside EmprestimosScreen's GridView.builder
                      itemBuilder: (context, index) {
                        final emprestimo = appState.paginatedEmprestimos[index];
                        return InkWell(
                          onTap: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Tela de detalhes ainda não implementada.')),
                            );
                          },
                          child: LoanCard(
                            loan: LoanData(
                              id: emprestimo.id.toString(),
                              clientName: emprestimo.nome,
                              totalAmount: emprestimo.valor,
                              nextPaymentDate: appState.dateFormat.format(emprestimo.dataVencimento!),
                              paidInstallments: 3,
                              totalInstallments: emprestimo.parcelas,
                              status: LoanStatus.emDia,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 1), // Reduzido de 8 para 4
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    border: Border(
                      top: BorderSide(
                        color: Colors.grey.withOpacity(0.2),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 24, // Altura fixa reduzida
                        decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.chevron_left, size: 20),
                              onPressed: appState.currentPage > 0
                                  ? () => appState.previousPage()
                                  : null,
                              tooltip: 'Anterior',
                              padding: EdgeInsets.zero,
                              color: appState.currentPage > 0
                                  ? Theme.of(context).primaryColor
                                  : Colors.grey,
                              constraints: const BoxConstraints(
                                minWidth: 32,
                                minHeight: 32,
                              ),
                            ),
                            Container(
                              constraints: const BoxConstraints(minWidth: 32),
                              alignment: Alignment.center,
                              child: Text(
                                '${appState.currentPage + 1}',
                                style: TextStyle(
                                  color: Theme.of(context).primaryColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.chevron_right, size: 20),
                              onPressed: (appState.currentPage + 1) * appState.itemsPerPage <
                                  appState.emprestimosRecentes.length
                                  ? () => appState.nextPage()
                                  : null,
                              tooltip: 'Próxima',
                              padding: EdgeInsets.zero,
                              color: (appState.currentPage + 1) * appState.itemsPerPage <
                                  appState.emprestimosRecentes.length
                                  ? Theme.of(context).primaryColor
                                  : Colors.grey,
                              constraints: const BoxConstraints(
                                minWidth: 32,
                                minHeight: 32,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton({
    required BuildContext context,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color color,
  }) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            height: 72,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: color.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 28, color: color),
                const SizedBox(height: 8),
                Text(
                  label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
