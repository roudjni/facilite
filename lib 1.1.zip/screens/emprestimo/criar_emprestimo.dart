import 'package:emprestafacil/data/models/simulacao.dart';
import 'package:emprestafacil/widgets/simulacao_form.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:emprestafacil/app/app_state.dart';
import 'package:emprestafacil/widgets/main_layout.dart';
import 'package:provider/provider.dart';
import 'package:emprestafacil/widgets/shared/app_button.dart';
import 'package:emprestafacil/widgets/shared/app_card.dart';
import 'package:emprestafacil/widgets/shared/app_text_field.dart';
import 'package:emprestafacil/theme/app_theme.dart';

class CriarEmprestimoScreen extends StatefulWidget {
  final Simulacao? simulacao;

  const CriarEmprestimoScreen({Key? key, this.simulacao}) : super(key: key);

  @override
  _CriarEmprestimoScreenState createState() => _CriarEmprestimoScreenState();
}

class _CriarEmprestimoScreenState extends State<CriarEmprestimoScreen> {
  final _cpfCnpjController = TextEditingController();
  final _whatsappController = TextEditingController();
  final _emailController = TextEditingController();
  final _enderecoController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  double _totalComJuros = 0.0;
  List<Map<String, dynamic>> _parcelasDetalhadas = [];

  void _handleSimulacaoCalculada(double totalComJuros, List<Map<String, dynamic>> parcelasDetalhadas) {
    setState(() {
      _totalComJuros = totalComJuros;
      _parcelasDetalhadas = parcelasDetalhadas;
    });
  }

  Future<void> _criarEmprestimo() async {
    if (!_formKey.currentState!.validate()) return;

    final appState = Provider.of<AppState>(context, listen: false);
    if (_parcelasDetalhadas.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Realize a simulação antes de criar o empréstimo!')),
        );
      });
      return;
    }

    appState.setLoading(true);

    try {
      await appState.criarEmprestimo(
        _cpfCnpjController.text,
        _whatsappController.text,
        _emailController.text,
        _enderecoController.text,
      );

      if (mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Empréstimo criado com sucesso!'),
              backgroundColor: Colors.green.withOpacity(0.9),
            ),
          );
        });
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao criar empréstimo: $e'),
            backgroundColor: Colors.red.withOpacity(0.9),
          ),
        );
      }
    } finally {
      appState.setLoading(false);
    }
  }

  @override
  void dispose() {
    _cpfCnpjController.dispose();
    _whatsappController.dispose();
    _emailController.dispose();
    _enderecoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return MainLayout(
      title: 'Criar Empréstimo',
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AppCard(
                child: SimulacaoForm(
                  simulacao: widget.simulacao,
                  onSimulacaoCalculada: _handleSimulacaoCalculada,
                ),
              ),
              const SizedBox(height: 16),
              AppCard(
                child: Column(
                  children: [
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: AppTextField(
                            controller: _cpfCnpjController,
                            label: 'CPF/CNPJ',
                            icon: Icons.badge_outlined,
                            keyboardType: TextInputType.number,
                            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                            validator: (value) => value?.isEmpty ?? true ? 'Digite o CPF/CNPJ' : null,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: AppTextField(
                            controller: _whatsappController,
                            label: 'WhatsApp',
                            icon: Icons.phone_android,
                            keyboardType: TextInputType.phone,
                            validator: (value) => value?.isEmpty ?? true ? 'Digite o número do WhatsApp' : null,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: AppTextField(
                            controller: _emailController,
                            label: 'Email (opcional)',
                            icon: Icons.email_outlined,
                            keyboardType: TextInputType.emailAddress,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: AppTextField(
                            controller: _enderecoController,
                            label: 'Endereço (opcional)',
                            icon: Icons.location_on_outlined,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              if (_parcelasDetalhadas.isNotEmpty) ...[
                const SizedBox(height: 24),
                _buildSimulacaoCard(appState),
                const SizedBox(height: 16),
                AppButton(
                  onPressed: _criarEmprestimo,
                  icon: Icons.add_circle_outline,
                  label: 'Criar Empréstimo',
                  color: Colors.green,
                ),
                const SizedBox(height: 8),
                AppButton(
                  onPressed: () => Navigator.pop(context),
                  icon: Icons.arrow_back,
                  label: 'Voltar',
                  color: Colors.grey,
                  outlined: true,
                ),
              ],
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSimulacaoCard(AppState appState) {
    return AppCard(
      child: Column(
        children: [
          Container(
            padding: AppTheme.cardPadding,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withOpacity(0.1),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Total a Pagar',
                      style: TextStyle(fontSize: 14, color: Colors.grey[400]),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      appState.numberFormat.format(_totalComJuros),
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${_parcelasDetalhadas.length}x de ${appState.numberFormat.format(_parcelasDetalhadas[0]['valor'])}',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Mensais'.toLowerCase(),
                      style: TextStyle(fontSize: 14, color: Colors.grey[400]),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: AppTheme.cardPadding,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Parcela',
                          style: TextStyle(color: Colors.grey[400]),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Valor',
                          style: TextStyle(color: Colors.grey[400]),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Vencimento',
                          style: TextStyle(color: Colors.grey[400]),
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1, color: Colors.white24),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _parcelasDetalhadas.length,
                  itemBuilder: (context, index) {
                    final parcela = _parcelasDetalhadas[index];
                    return Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Colors.white.withOpacity(0.1),
                          ),
                        ),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              '${parcela['numero']}ª',
                              style: TextStyle(
                                color: Theme.of(context).primaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Text(
                              appState.numberFormat.format(parcela['valor']),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Text(
                              parcela['dataVencimento'],
                              style: TextStyle(color: Colors.grey[400]),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
